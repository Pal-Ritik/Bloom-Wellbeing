export type MoodLevel = 1 | 2 | 3 | 4 | 5;

export interface MoodMeta {
  level: MoodLevel;
  label: string;
  emoji: string;
  description: string;
  color: string;
  textColor: string;
  bgColor: string;
  borderColor: string;
}

export interface CheckIn {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  timestamp: number;
  mood: MoodLevel;
  energy: number; // 1 to 5
  emotions: string[];
  reflection?: string;
  timeOfDay: 'Morning' | 'Afternoon' | 'Evening' | 'Night';
}

export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  timestamp: number;
  mood: MoodLevel;
  promptUsed?: string;
  tags: string[];
  isFavorite: boolean;
}

export type SelfCareCategory = 'breathing' | 'meditation' | 'stretching' | 'gratitude' | 'sleep' | 'walk';

export interface SelfCareActivity {
  id: string;
  category: SelfCareCategory;
  title: string;
  tagline: string;
  description: string;
  duration: string;
  benefits: string;
  iconName: string;
  colorTheme: {
    bg: string;
    text: string;
    badge: string;
    border: string;
  };
}

export interface Affirmation {
  id: string;
  text: string;
  author: string;
  theme: string;
}

export type ActiveTab = 'dashboard' | 'checkin' | 'journal' | 'insights' | 'selfcare';
