/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ActiveTab, CheckIn, JournalEntry } from './types/wellbeing';
import {
  loadCheckIns,
  saveCheckIns,
  loadJournalEntries,
  saveJournalEntries,
  loadMindfulMinutes,
  addMindfulMinutes,
} from './utils/storage';
import { sound } from './utils/audio';
import { Sidebar } from './components/navigation/Sidebar';
import { MobileNav } from './components/navigation/MobileNav';
import { Header } from './components/common/Header';
import { Dashboard } from './components/dashboard/Dashboard';
import { MoodCheckin } from './components/checkin/MoodCheckin';
import { JournalView } from './components/journal/JournalView';
import { MoodInsights } from './components/insights/MoodInsights';
import { SelfCareView } from './components/selfcare/SelfCareView';
import { SelfCareModal } from './components/selfcare/SelfCareModals';
import { getSeedCheckIns, getSeedJournalEntries } from './data/seedData';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [checkIns, setCheckIns] = useState<CheckIn[]>([]);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([]);
  const [mindfulMinutes, setMindfulMinutes] = useState<number>(42);
  const [isAmbientPlaying, setIsAmbientPlaying] = useState<boolean>(false);
  const [activeSelfCareModal, setActiveSelfCareModal] = useState<string | null>(null);

  // Initialize data on mount
  useEffect(() => {
    const loadedCheckIns = loadCheckIns();
    const loadedJournal = loadJournalEntries();
    const loadedMinutes = loadMindfulMinutes();

    setCheckIns(loadedCheckIns);
    setJournalEntries(loadedJournal);
    setMindfulMinutes(loadedMinutes);
  }, []);

  // Handlers
  const handleToggleAmbient = () => {
    const nextState = sound.toggleAmbientRain(!isAmbientPlaying);
    setIsAmbientPlaying(nextState);
  };

  const handleSaveCheckIn = (newCheckIn: Omit<CheckIn, 'id' | 'timestamp'>) => {
    const item: CheckIn = {
      ...newCheckIn,
      id: `chk-${Date.now()}`,
      timestamp: Date.now(),
    };
    const updated = [item, ...checkIns];
    setCheckIns(updated);
    saveCheckIns(updated);

    // Increment mindful minutes for taking time to reflect
    const updatedMins = addMindfulMinutes(2);
    setMindfulMinutes(updatedMins);
  };

  const handleAddJournalEntry = (entry: Omit<JournalEntry, 'id' | 'timestamp'>) => {
    const item: JournalEntry = {
      ...entry,
      id: `jrn-${Date.now()}`,
      timestamp: Date.now(),
    };
    const updated = [item, ...journalEntries];
    setJournalEntries(updated);
    saveJournalEntries(updated);

    const updatedMins = addMindfulMinutes(3);
    setMindfulMinutes(updatedMins);
  };

  const handleUpdateJournalEntry = (id: string, updatedFields: Partial<JournalEntry>) => {
    const updated = journalEntries.map((j) =>
      j.id === id ? { ...j, ...updatedFields } : j
    );
    setJournalEntries(updated);
    saveJournalEntries(updated);
  };

  const handleDeleteJournalEntry = (id: string) => {
    const updated = journalEntries.filter((j) => j.id !== id);
    setJournalEntries(updated);
    saveJournalEntries(updated);
  };

  const handleAddMinutes = (mins: number) => {
    const updated = addMindfulMinutes(mins);
    setMindfulMinutes(updated);
  };

  const handleSaveGratitudeEntry = (threeThings: string[]) => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const formattedContent = threeThings
      .map((item, idx) => `${idx + 1}. ${item}`)
      .join('\n');

    const entry: JournalEntry = {
      id: `jrn-${Date.now()}`,
      title: 'Three Simple Joys',
      content: `Moments of gratitude noticed today:\n\n${formattedContent}`,
      date: dateStr,
      time: timeStr,
      timestamp: Date.now(),
      mood: 5,
      promptUsed: 'Name three sights or sounds that brought you peace.',
      tags: ['Gratitude', 'Daily Joys', 'Mindfulness'],
      isFavorite: true,
    };

    const updated = [entry, ...journalEntries];
    setJournalEntries(updated);
    saveJournalEntries(updated);
  };

  const handleResetToDemo = () => {
    if (confirm('Reset to initial sample wellbeing entries and journal reflections?')) {
      const freshCheckIns = getSeedCheckIns();
      const freshJournal = getSeedJournalEntries();
      setCheckIns(freshCheckIns);
      saveCheckIns(freshCheckIns);
      setJournalEntries(freshJournal);
      saveJournalEntries(freshJournal);
      setMindfulMinutes(42);
      localStorage.setItem('bloom_wellbeing_minutes_v1', '42');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F1] flex flex-col md:flex-row text-stone-800 antialiased selection:bg-[#8BAF9C]/30 selection:text-[#315C4C]">
      {/* Desktop Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isAmbientPlaying={isAmbientPlaying}
        onToggleAmbient={handleToggleAmbient}
        mindfulMinutes={mindfulMinutes}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Top Header */}
        <Header
          activeTab={activeTab}
          onOpenCheckIn={() => setActiveTab('checkin')}
          isAmbientPlaying={isAmbientPlaying}
          onToggleAmbient={handleToggleAmbient}
        />

        {/* Content View Container */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              checkIns={checkIns}
              onOpenCheckIn={() => setActiveTab('checkin')}
              onOpenSelfCare={(actId) => setActiveSelfCareModal(actId)}
              onNavigateTab={setActiveTab}
              mindfulMinutes={mindfulMinutes}
            />
          )}

          {activeTab === 'checkin' && (
            <MoodCheckin
              onSaveCheckIn={handleSaveCheckIn}
              onNavigateHome={() => setActiveTab('dashboard')}
            />
          )}

          {activeTab === 'journal' && (
            <JournalView
              entries={journalEntries}
              onAddEntry={handleAddJournalEntry}
              onUpdateEntry={handleUpdateJournalEntry}
              onDeleteEntry={handleDeleteJournalEntry}
            />
          )}

          {activeTab === 'insights' && (
            <MoodInsights checkIns={checkIns} />
          )}

          {activeTab === 'selfcare' && (
            <SelfCareView
              onOpenActivity={(id) => setActiveSelfCareModal(id)}
              mindfulMinutes={mindfulMinutes}
            />
          )}
        </main>

        {/* Footer with peaceful tone & demo reset option */}
        <footer className="border-t border-[#8BAF9C]/15 py-6 px-4 text-center text-xs text-stone-500 hidden md:block">
          <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
            <span>Bloom — Your Daily Wellbeing Companion · Nourishing mindful presence</span>
            <div className="flex items-center gap-4">
              <button
                onClick={handleResetToDemo}
                className="hover:text-stone-800 underline transition-colors"
              >
                Reset Demo Data
              </button>
              <span>·</span>
              <button
                onClick={handleToggleAmbient}
                className="hover:text-stone-800 transition-colors"
              >
                {isAmbientPlaying ? 'Mute Ambiance' : 'Play Forest Rain'}
              </button>
            </div>
          </div>
        </footer>

        {/* Mobile Bottom Navigation */}
        <MobileNav activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>

      {/* Interactive Self-Care Modal */}
      <SelfCareModal
        activityId={activeSelfCareModal}
        onClose={() => setActiveSelfCareModal(null)}
        onAddMindfulMinutes={handleAddMinutes}
        onSaveGratitudeEntry={handleSaveGratitudeEntry}
      />
    </div>
  );
}
