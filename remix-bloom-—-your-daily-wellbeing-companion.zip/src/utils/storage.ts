import { CheckIn, JournalEntry } from '../types/wellbeing';
import { getSeedCheckIns, getSeedJournalEntries } from '../data/seedData';

const STORAGE_KEYS = {
  CHECK_INS: 'bloom_wellbeing_checkins_v1',
  JOURNAL_ENTRIES: 'bloom_wellbeing_journal_v1',
  MINDFUL_MINUTES: 'bloom_wellbeing_minutes_v1',
};

export function loadCheckIns(): CheckIn[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CHECK_INS);
    if (!raw) {
      const seeded = getSeedCheckIns();
      saveCheckIns(seeded);
      return seeded;
    }
    return JSON.parse(raw);
  } catch {
    return getSeedCheckIns();
  }
}

export function saveCheckIns(items: CheckIn[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.CHECK_INS, JSON.stringify(items));
  } catch (e) {
    console.error('Failed to save checkins', e);
  }
}

export function loadJournalEntries(): JournalEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.JOURNAL_ENTRIES);
    if (!raw) {
      const seeded = getSeedJournalEntries();
      saveJournalEntries(seeded);
      return seeded;
    }
    return JSON.parse(raw);
  } catch {
    return getSeedJournalEntries();
  }
}

export function saveJournalEntries(items: JournalEntry[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.JOURNAL_ENTRIES, JSON.stringify(items));
  } catch (e) {
    console.error('Failed to save journal entries', e);
  }
}

export function loadMindfulMinutes(): number {
  try {
    const val = localStorage.getItem(STORAGE_KEYS.MINDFUL_MINUTES);
    return val ? parseInt(val, 10) : 42;
  } catch {
    return 42;
  }
}

export function addMindfulMinutes(mins: number): number {
  try {
    const current = loadMindfulMinutes();
    const updated = current + mins;
    localStorage.setItem(STORAGE_KEYS.MINDFUL_MINUTES, updated.toString());
    return updated;
  } catch {
    return 42 + mins;
  }
}
