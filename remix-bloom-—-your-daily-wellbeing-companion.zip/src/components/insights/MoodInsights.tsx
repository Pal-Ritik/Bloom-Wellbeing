import React, { useState } from 'react';
import { BarChart3, TrendingUp, Zap, Calendar, Heart, Sparkles, Clock, CheckCircle } from 'lucide-react';
import { CheckIn, MoodLevel } from '../../types/wellbeing';
import { MOOD_DEFINITIONS } from '../../data/seedData';

interface MoodInsightsProps {
  checkIns: CheckIn[];
}

export const MoodInsights: React.FC<MoodInsightsProps> = ({ checkIns }) => {
  const [timeRange, setTimeRange] = useState<'7d' | '14d' | 'month'>('14d');

  // Sorted by date ascending for charts
  const sortedAsc = [...checkIns].sort((a, b) => a.timestamp - b.timestamp);
  const dataSlice = timeRange === '7d' ? sortedAsc.slice(-7) : timeRange === '14d' ? sortedAsc.slice(-14) : sortedAsc;

  // Mood distribution counts
  const moodCounts: Record<MoodLevel, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  let totalEnergy = 0;
  dataSlice.forEach((c) => {
    moodCounts[c.mood] = (moodCounts[c.mood] || 0) + 1;
    totalEnergy += c.energy;
  });

  const totalEntries = dataSlice.length || 1;
  const avgEnergy = (totalEnergy / totalEntries).toFixed(1);

  // Most common emotion
  const emotionFrequency: Record<string, number> = {};
  dataSlice.forEach((c) => {
    c.emotions.forEach((em) => {
      emotionFrequency[em] = (emotionFrequency[em] || 0) + 1;
    });
  });
  const topEmotions = Object.entries(emotionFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // Time of day pattern
  const timeOfDayMap: Record<string, { totalMood: number; count: number }> = {
    Morning: { totalMood: 0, count: 0 },
    Afternoon: { totalMood: 0, count: 0 },
    Evening: { totalMood: 0, count: 0 },
  };
  dataSlice.forEach((c) => {
    if (timeOfDayMap[c.timeOfDay]) {
      timeOfDayMap[c.timeOfDay].totalMood += c.mood;
      timeOfDayMap[c.timeOfDay].count += 1;
    }
  });

  // Calendar for October 2026 (1 to 31)
  const currentMonthDays = Array.from({ length: 31 }, (_, i) => {
    const dayNum = i + 1;
    const dateStr = `2026-10-${dayNum.toString().padStart(2, '0')}`;
    const checkIn = checkIns.find((c) => c.date === dateStr);
    return { dayNum, dateStr, checkIn };
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-br from-[#EBF2EE] via-white to-[#F5D8CC]/20 border border-[#8BAF9C]/25 p-6 sm:p-7 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#315C4C] uppercase tracking-wider">
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Personal Insights</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#315C4C] mt-1">
              Your Emotional Landscape
            </h2>
            <p className="text-stone-600 text-xs sm:text-sm mt-1 max-w-lg">
              Supportive reflections drawn from your logs. Notice your natural ebbs and flows without judgment.
            </p>
          </div>

          {/* Time range selector */}
          <div className="flex items-center gap-1 p-1 bg-white border border-[#8BAF9C]/30 rounded-xl text-xs font-medium self-start sm:self-auto shadow-2xs">
            <button
              onClick={() => setTimeRange('7d')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                timeRange === '7d'
                  ? 'bg-[#315C4C] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              7 Days
            </button>
            <button
              onClick={() => setTimeRange('14d')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                timeRange === '14d'
                  ? 'bg-[#315C4C] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              14 Days
            </button>
            <button
              onClick={() => setTimeRange('month')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                timeRange === 'month'
                  ? 'bg-[#315C4C] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              All Month
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-stone-500 mb-2">
            <span className="uppercase tracking-wider font-medium">Logged Check-ins</span>
            <Calendar className="w-4 h-4 text-[#8BAF9C]" />
          </div>
          <div className="font-display text-3xl font-bold text-[#315C4C] tabular-nums">
            {dataSlice.length}
          </div>
          <span className="text-xs text-stone-500 mt-1 block">
            Consistent records in selected period
          </span>
        </div>

        <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-stone-500 mb-2">
            <span className="uppercase tracking-wider font-medium">Average Energy</span>
            <Zap className="w-4 h-4 text-amber-500" />
          </div>
          <div className="font-display text-3xl font-bold text-[#315C4C] tabular-nums">
            {avgEnergy} <span className="text-lg font-normal text-stone-400">/ 5</span>
          </div>
          <span className="text-xs text-stone-500 mt-1 block">
            Balanced daily stamina
          </span>
        </div>

        <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-stone-500 mb-2">
            <span className="uppercase tracking-wider font-medium">Primary Emotion</span>
            <Heart className="w-4 h-4 text-[#58447E]" />
          </div>
          <div className="font-display text-2xl font-bold text-[#58447E]">
            {topEmotions[0]?.[0] || 'Calm'}
          </div>
          <span className="text-xs text-stone-500 mt-1 block">
            Logged in {topEmotions[0]?.[1] || 0} recent reflections
          </span>
        </div>
      </div>

      {/* Weekly & Bi-Weekly Mood + Energy Trajectory Chart */}
      <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <span className="text-xs text-stone-400 font-medium uppercase tracking-wider">
              Dual Trajectory
            </span>
            <h3 className="font-display text-lg font-semibold text-[#315C4C]">
              Mood & Energy Correlation Over Time
            </h3>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5 text-[#315C4C] font-semibold">
              <span className="w-3 h-1 bg-[#315C4C] rounded-full" />
              <span>Mood (1-5)</span>
            </div>
            <div className="flex items-center gap-1.5 text-amber-600 font-semibold">
              <span className="w-3 h-1 bg-amber-400 rounded-full" />
              <span>Energy (1-5)</span>
            </div>
          </div>
        </div>

        {/* Chart SVG */}
        <div className="w-full h-56 sm:h-64 my-2">
          <svg viewBox="0 0 600 200" className="w-full h-full overflow-visible">
            {/* Horizontal lines */}
            {[1, 2, 3, 4, 5].map((lvl) => {
              const y = 170 - (lvl - 1) * 35;
              return (
                <g key={lvl}>
                  <line
                    x1="40"
                    y1={y}
                    x2="580"
                    y2={y}
                    stroke="#F1EFEA"
                    strokeWidth="1.5"
                  />
                  <text
                    x="20"
                    y={y + 4}
                    className="text-[10px] fill-stone-400 font-mono tabular-nums"
                  >
                    {lvl}
                  </text>
                </g>
              );
            })}

            {(() => {
              if (dataSlice.length < 2) return null;

              const moodPoints = dataSlice.map((d, i) => {
                const x = 50 + i * ((570 - 50) / (dataSlice.length - 1));
                const y = 170 - (d.mood - 1) * 35;
                return { x, y, d };
              });

              const energyPoints = dataSlice.map((d, i) => {
                const x = 50 + i * ((570 - 50) / (dataSlice.length - 1));
                const y = 170 - (d.energy - 1) * 35;
                return { x, y, d };
              });

              const moodD = moodPoints.reduce(
                (acc, p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`),
                ''
              );

              const energyD = energyPoints.reduce(
                (acc, p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`),
                ''
              );

              return (
                <>
                  {/* Energy Line */}
                  <path
                    d={energyD}
                    fill="none"
                    stroke="#F59E0B"
                    strokeWidth="2"
                    strokeDasharray="4 4"
                    strokeLinecap="round"
                  />
                  {/* Mood Line */}
                  <path
                    d={moodD}
                    fill="none"
                    stroke="#315C4C"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Mood Data Dots */}
                  {moodPoints.map((p, i) => (
                    <circle
                      key={`m-${i}`}
                      cx={p.x}
                      cy={p.y}
                      r="4.5"
                      fill="#FAF8F1"
                      stroke="#315C4C"
                      strokeWidth="2"
                    />
                  ))}

                  {/* Date labels */}
                  {moodPoints.map((p, i) => (
                    <text
                      key={`t-${i}`}
                      x={p.x}
                      y="190"
                      textAnchor="middle"
                      className="text-[9px] fill-stone-400 font-medium"
                    >
                      {p.d.date.slice(8)}
                    </text>
                  ))}
                </>
              );
            })()}
          </svg>
        </div>

        <div className="text-xs text-stone-500 pt-3 border-t border-stone-100 flex items-center justify-between">
          <span>Horizontal axis represents day of October</span>
          <span className="italic text-[#315C4C]">
            Mood and energy often harmonize following outdoor walks
          </span>
        </div>
      </div>

      {/* Monthly Heatmap & Mood Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Monthly Calendar Overview */}
        <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display text-base font-semibold text-[#315C4C]">
                October 2026 Calendar
              </h3>
              <span className="text-xs text-stone-400">Daily check-in presence</span>
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-1.5 text-center my-3">
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
                <div key={i} className="text-[11px] font-semibold text-stone-400 py-1">
                  {day}
                </div>
              ))}

              {/* Offset for Oct 1, 2026 (Thursday = 4 empty cells) */}
              {[...Array(4)].map((_, i) => (
                <div key={`empty-${i}`} className="p-2" />
              ))}

              {currentMonthDays.map(({ dayNum, checkIn }) => {
                const hasCheckIn = !!checkIn;
                const moodMeta = hasCheckIn ? MOOD_DEFINITIONS[checkIn.mood] : null;

                return (
                  <div
                    key={dayNum}
                    className={`p-1.5 rounded-xl border flex flex-col items-center justify-center min-h-[42px] transition-all ${
                      hasCheckIn
                        ? 'border-[#8BAF9C]/40 bg-[#EBF2EE] text-[#315C4C]'
                        : 'border-transparent text-stone-400'
                    }`}
                    title={
                      hasCheckIn
                        ? `Oct ${dayNum}: ${moodMeta?.label} (${checkIn.emotions.join(', ')})`
                        : `Oct ${dayNum}: No log`
                    }
                  >
                    <span className="text-xs font-semibold tabular-nums">{dayNum}</span>
                    {hasCheckIn ? (
                      <span className="text-xs leading-none mt-0.5">{moodMeta?.emoji}</span>
                    ) : (
                      <span className="w-1 h-1 rounded-full bg-stone-200 mt-1" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
            <span>Color coded by recorded daily state</span>
            <span className="text-[#315C4C] font-medium">{checkIns.length} days active</span>
          </div>
        </div>

        {/* Mood Distribution Breakdown */}
        <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display text-base font-semibold text-[#315C4C]">
                Mood Balance Distribution
              </h3>
              <span className="text-xs text-stone-400">Total proportion</span>
            </div>

            <div className="space-y-3 my-4">
              {([5, 4, 3, 2, 1] as MoodLevel[]).map((level) => {
                const meta = MOOD_DEFINITIONS[level];
                const count = moodCounts[level] || 0;
                const pct = Math.round((count / totalEntries) * 100);

                return (
                  <div key={level} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-2 font-medium text-stone-700">
                        <span>{meta.emoji}</span>
                        <span>{meta.label}</span>
                      </span>
                      <span className="text-stone-400 tabular-nums">
                        {count} days ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-[#EBF2EE] h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${pct}%`,
                          backgroundColor: meta.color,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-3 border-t border-stone-100 text-xs text-stone-500">
            Predominantly settled and calm ({Math.round(((moodCounts[4] + moodCounts[5]) / totalEntries) * 100)}% positive or steady)
          </div>
        </div>
      </div>

      {/* Supportive, Non-Medical Insights Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="rounded-2xl bg-[#EBF2EE]/60 border border-[#8BAF9C]/30 p-5 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#315C4C]">
            <Sparkles className="w-4 h-4" />
            <span>Gentle Pattern Observation</span>
          </div>
          <h4 className="font-display text-base font-semibold text-[#315C4C]">
            Mornings Offer Your Clearest Equilibrium
          </h4>
          <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
            Over the past two weeks, check-ins logged before 10 AM show your highest feelings of calm and hopefulness. Preserving quiet, unhurried morning routines creates a peaceful anchor for the rest of your day.
          </p>
        </div>

        <div className="rounded-2xl bg-[#FAF4EE]/70 border border-[#F5D8CC] p-5 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#9A5B32]">
            <TrendingUp className="w-4 h-4" />
            <span>Restorative Correlation</span>
          </div>
          <h4 className="font-display text-base font-semibold text-[#7A421E]">
            Breathing & Nature Correlate With Energy Lift
          </h4>
          <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
            Days where your journal mentions outdoor walks or breathing exercises show a 1.2 point increase in afternoon energy compared to sedentary days.
          </p>
        </div>
      </div>
    </div>
  );
};
