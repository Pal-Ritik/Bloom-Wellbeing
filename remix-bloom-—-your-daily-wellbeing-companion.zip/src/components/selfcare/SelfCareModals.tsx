import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, Check, Heart, Wind, Moon, Sparkles, CheckCircle2 } from 'lucide-react';
import { sound } from '../../utils/audio';

interface SelfCareModalProps {
  activityId: string | null;
  onClose: () => void;
  onAddMindfulMinutes: (mins: number) => void;
  onSaveGratitudeEntry?: (threeThings: string[]) => void;
}

export const SelfCareModal: React.FC<SelfCareModalProps> = ({
  activityId,
  onClose,
  onAddMindfulMinutes,
  onSaveGratitudeEntry,
}) => {
  if (!activityId) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-xs animate-fadeIn"
    >
      <div className="bg-[#FAF8F1] border border-[#8BAF9C]/30 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl relative p-6 sm:p-8 text-stone-800">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 transition-colors"
          aria-label="Close activity"
        >
          <X className="w-5 h-5" />
        </button>

        {activityId === 'breathing' && (
          <BreathingExercise onComplete={onAddMindfulMinutes} onClose={onClose} />
        )}
        {activityId === 'meditation' && (
          <MeditationTimer onComplete={onAddMindfulMinutes} onClose={onClose} />
        )}
        {activityId === 'stretching' && (
          <StretchingFlow onComplete={onAddMindfulMinutes} onClose={onClose} />
        )}
        {activityId === 'gratitude' && (
          <GratitudeBuilder
            onSave={(items) => {
              if (onSaveGratitudeEntry) onSaveGratitudeEntry(items);
              onAddMindfulMinutes(4);
              onClose();
            }}
          />
        )}
        {activityId === 'sleep' && (
          <SleepSanctuary onComplete={onAddMindfulMinutes} onClose={onClose} />
        )}
        {activityId === 'walk' && (
          <NatureWalkGuide onComplete={onAddMindfulMinutes} onClose={onClose} />
        )}
      </div>
    </div>
  );
};

/* 1. Breathing Exercise Modal */
const BreathingExercise: React.FC<{
  onComplete: (mins: number) => void;
  onClose: () => void;
}> = ({ onComplete }) => {
  const [pattern, setPattern] = useState<'box' | 'relax'>('box'); // box: 4-4-4-4, relax: 4-7-8
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Rest'>('Inhale');
  const [secondsLeft, setSecondsLeft] = useState(4);
  const [cycleCount, setCycleCount] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;

    if (isActive && !isFinished) {
      timer = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            // Next phase
            if (pattern === 'box') {
              if (phase === 'Inhale') {
                setPhase('Hold');
                sound.playBreathBell(false);
                return 4;
              } else if (phase === 'Hold') {
                setPhase('Exhale');
                sound.playBreathBell(false);
                return 4;
              } else if (phase === 'Exhale') {
                setPhase('Rest');
                return 4;
              } else {
                setPhase('Inhale');
                setCycleCount((c) => {
                  const updated = c + 1;
                  if (updated >= 4) {
                    setIsFinished(true);
                    setIsActive(false);
                    onComplete(3);
                    sound.playChime(528, 3.5);
                  }
                  return updated;
                });
                sound.playBreathBell(true);
                return 4;
              }
            } else {
              // 4-7-8 Relaxing
              if (phase === 'Inhale') {
                setPhase('Hold');
                sound.playBreathBell(false);
                return 7;
              } else if (phase === 'Hold') {
                setPhase('Exhale');
                sound.playBreathBell(false);
                return 8;
              } else {
                setPhase('Inhale');
                setCycleCount((c) => {
                  const updated = c + 1;
                  if (updated >= 4) {
                    setIsFinished(true);
                    setIsActive(false);
                    onComplete(3);
                    sound.playChime(528, 3.5);
                  }
                  return updated;
                });
                sound.playBreathBell(true);
                return 4;
              }
            }
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(timer);
  }, [isActive, phase, secondsLeft, pattern, isFinished, onComplete]);

  const handleStart = () => {
    setIsActive(true);
    setIsFinished(false);
    setPhase('Inhale');
    setSecondsLeft(4);
    setCycleCount(0);
    sound.playBreathBell(true);
  };

  const getScaleClass = () => {
    if (!isActive) return 'scale-90 opacity-75';
    if (phase === 'Inhale') return 'scale-125 duration-4000';
    if (phase === 'Hold') return 'scale-125 duration-1000';
    if (phase === 'Exhale') return 'scale-90 duration-4000';
    return 'scale-90 duration-1000';
  };

  return (
    <div className="flex flex-col items-center text-center">
      <div className="flex items-center gap-2 text-xs font-semibold text-[#315C4C] bg-[#8BAF9C]/20 px-3 py-1 rounded-full mb-3">
        <Wind className="w-3.5 h-3.5" />
        <span>Paced Breathing Practice</span>
      </div>

      <h3 className="font-display text-2xl font-semibold text-[#315C4C]">
        {pattern === 'box' ? 'Box Breathing (4-4-4-4)' : 'Relaxing Breath (4-7-8)'}
      </h3>
      <p className="text-xs sm:text-sm text-stone-600 mt-1 max-w-md">
        Follow the natural rhythmic expansion and contraction. Soften your jaw and shoulders.
      </p>

      {/* Pattern Selector */}
      <div className="flex items-center gap-2 mt-4 p-1 bg-[#EBF2EE] rounded-xl text-xs font-medium">
        <button
          onClick={() => {
            setPattern('box');
            setIsActive(false);
            setPhase('Inhale');
            setSecondsLeft(4);
          }}
          className={`px-3 py-1.5 rounded-lg transition-all ${
            pattern === 'box'
              ? 'bg-[#315C4C] text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          Box 4-4-4-4
        </button>
        <button
          onClick={() => {
            setPattern('relax');
            setIsActive(false);
            setPhase('Inhale');
            setSecondsLeft(4);
          }}
          className={`px-3 py-1.5 rounded-lg transition-all ${
            pattern === 'relax'
              ? 'bg-[#315C4C] text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          4-7-8 Calming
        </button>
      </div>

      {/* Expanding Breathing Orb */}
      <div className="relative my-10 flex items-center justify-center w-56 h-56">
        <div
          className={`absolute inset-0 rounded-full bg-gradient-to-tr from-[#8BAF9C]/30 via-[#E9E3F5]/40 to-[#F5D8CC]/30 transition-transform ease-in-out ${getScaleClass()}`}
        />
        <div
          className={`absolute w-44 h-44 rounded-full bg-white/80 border border-[#8BAF9C]/40 backdrop-blur-xs flex flex-col items-center justify-center shadow-md transition-all`}
        >
          <span className="text-xs font-medium text-stone-500 uppercase tracking-widest">
            {isActive ? phase : 'Ready'}
          </span>
          <span className="font-display text-4xl font-bold text-[#315C4C] my-1 tabular-nums">
            {isActive ? secondsLeft : '4'}
          </span>
          <span className="text-[11px] text-stone-400">
            {isActive ? `Cycle ${cycleCount + 1} of 4` : 'Press start below'}
          </span>
        </div>
      </div>

      {isFinished ? (
        <div className="bg-[#E1EFE8] border border-[#8BAF9C] text-[#224033] p-4 rounded-xl max-w-sm mb-4 animate-fadeIn">
          <div className="flex items-center justify-center gap-2 font-semibold text-sm mb-1">
            <CheckCircle2 className="w-4 h-4 text-[#315C4C]" />
            Session Complete
          </div>
          <p className="text-xs text-stone-600">
            Notice how your body feels right now. +3 mindful minutes added to your sanctuary.
          </p>
        </div>
      ) : null}

      {/* Controls */}
      <div className="flex items-center gap-3">
        {!isActive ? (
          <button
            onClick={handleStart}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] font-medium text-sm hover:bg-[#25483B] transition-all shadow-sm"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{isFinished ? 'Breathe Again' : 'Begin Practice'}</span>
          </button>
        ) : (
          <button
            onClick={() => setIsActive(false)}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-stone-200 text-stone-700 font-medium text-sm hover:bg-stone-300 transition-all"
          >
            <Pause className="w-4 h-4" />
            <span>Pause</span>
          </button>
        )}
      </div>
    </div>
  );
};

/* 2. Guided Meditation Timer */
const MeditationTimer: React.FC<{
  onComplete: (mins: number) => void;
  onClose: () => void;
}> = ({ onComplete }) => {
  const [selectedMinutes, setSelectedMinutes] = useState(5);
  const [secondsRemaining, setSecondsRemaining] = useState(5 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  const guidanceNotes = [
    'Allow your breathing to settle into its natural rhythm.',
    'Notice the gentle contact of your feet against the earth.',
    'If thoughts arise, observe them like passing clouds in an open sky.',
    'Gently soften any tension around your eyes and shoulders.',
    'Rest right here in this quiet, unhurried space.',
  ];

  const [currentTipIndex, setCurrentTipIndex] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && secondsRemaining > 0) {
      interval = setInterval(() => {
        setSecondsRemaining((s) => {
          if (s <= 1) {
            setIsRunning(false);
            setIsCompleted(true);
            onComplete(selectedMinutes);
            sound.playChime(432, 4);
            return 0;
          }
          if (s % 30 === 0) {
            setCurrentTipIndex((prev) => (prev + 1) % guidanceNotes.length);
          }
          return s - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, secondsRemaining, selectedMinutes, onComplete, guidanceNotes.length]);

  const handleStart = () => {
    if (secondsRemaining === 0) {
      setSecondsRemaining(selectedMinutes * 60);
      setIsCompleted(false);
    }
    setIsRunning(true);
    sound.playChime(432, 3);
  };

  const handleReset = () => {
    setIsRunning(false);
    setIsCompleted(false);
    setSecondsRemaining(selectedMinutes * 60);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="flex flex-col items-center text-center">
      <div className="flex items-center gap-2 text-xs font-semibold text-[#58447E] bg-[#E9E3F5] px-3 py-1 rounded-full mb-3">
        <Sparkles className="w-3.5 h-3.5" />
        <span>Quiet Awareness</span>
      </div>

      <h3 className="font-display text-2xl font-semibold text-[#315C4C]">Grounding Stillness</h3>
      <p className="text-xs sm:text-sm text-stone-600 mt-1 max-w-md">
        Give yourself a few quiet minutes without demands or expectations.
      </p>

      {/* Minute Selector */}
      {!isRunning && !isCompleted && (
        <div className="flex items-center gap-2 mt-4 p-1 bg-[#EBF2EE] rounded-xl text-xs font-medium">
          {[3, 5, 10].map((mins) => (
            <button
              key={mins}
              onClick={() => {
                setSelectedMinutes(mins);
                setSecondsRemaining(mins * 60);
              }}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedMinutes === mins
                  ? 'bg-[#315C4C] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {mins} Minutes
            </button>
          ))}
        </div>
      )}

      {/* Clock display */}
      <div className="my-8 flex flex-col items-center justify-center w-48 h-48 rounded-full border-4 border-[#8BAF9C]/30 bg-white shadow-inner">
        <span className="font-display text-4xl font-bold text-[#315C4C] tracking-tight tabular-nums">
          {formatTime(secondsRemaining)}
        </span>
        <span className="text-xs text-stone-400 mt-1">
          {isRunning ? 'in quiet presence' : 'ready to begin'}
        </span>
      </div>

      {/* Guidance step */}
      <div className="min-h-[44px] px-4 py-2 bg-[#F1F7F4] border border-[#B9D4C7]/50 rounded-xl max-w-sm mb-6 text-xs text-[#224033] italic">
        "{guidanceNotes[currentTipIndex]}"
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        {!isRunning ? (
          <button
            onClick={handleStart}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] font-medium text-sm hover:bg-[#25483B] transition-all shadow-sm"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{isCompleted ? 'Meditate Again' : 'Start Timer'}</span>
          </button>
        ) : (
          <button
            onClick={() => setIsRunning(false)}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-stone-200 text-stone-700 font-medium text-sm hover:bg-stone-300 transition-all"
          >
            <Pause className="w-4 h-4" />
            <span>Pause</span>
          </button>
        )}
        <button
          onClick={handleReset}
          className="p-2.5 rounded-xl border border-stone-200 text-stone-500 hover:text-stone-800 hover:bg-stone-100 transition-colors"
          title="Reset timer"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

/* 3. Stretching Flow */
const StretchingFlow: React.FC<{
  onComplete: (mins: number) => void;
  onClose: () => void;
}> = ({ onComplete }) => {
  const stretches = [
    {
      title: 'Gentle Neck & Shoulder Release',
      instruction: 'Drop right ear to right shoulder softly. Take three deep breaths, then switch gently to the left.',
      duration: '45s',
    },
    {
      title: 'Seated Spinal Twist',
      instruction: 'Place right hand on left knee. Inhale to lengthen your spine, exhale to gently rotate through your ribcage.',
      duration: '45s',
    },
    {
      title: 'Heart-Opening Chest Stretch',
      instruction: 'Interlace fingers behind your lower back or hold your chair edges. Draw shoulder blades together and gaze slightly upward.',
      duration: '45s',
    },
    {
      title: 'Side Body Crescent Reach',
      instruction: 'Reach right arm overhead and lean softly to the left. Feel space opening between your ribs. Repeat on other side.',
      duration: '45s',
    },
  ];

  const [activeStep, setActiveStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const toggleStep = (index: number) => {
    sound.playChime(480, 1.5);
    if (completedSteps.includes(index)) {
      setCompletedSteps(completedSteps.filter((i) => i !== index));
    } else {
      const updated = [...completedSteps, index];
      setCompletedSteps(updated);
      if (updated.length === stretches.length) {
        onComplete(6);
      }
    }
  };

  return (
    <div className="flex flex-col text-left">
      <div className="text-center mb-6">
        <h3 className="font-display text-2xl font-semibold text-[#315C4C]">Gentle Body Unwind</h3>
        <p className="text-xs sm:text-sm text-stone-600 mt-1">
          Desk-friendly gentle releases. Listen to your body and move with slow kindness.
        </p>
      </div>

      <div className="space-y-3 mb-6">
        {stretches.map((stretch, idx) => {
          const isDone = completedSteps.includes(idx);
          const isSelected = activeStep === idx;
          return (
            <div
              key={idx}
              onClick={() => setActiveStep(idx)}
              className={`p-4 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-white border-[#8BAF9C] shadow-sm'
                  : 'bg-[#F9F7F0] border-stone-200/60 hover:bg-white'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleStep(idx);
                    }}
                    className={`mt-0.5 w-5 h-5 rounded-md flex items-center justify-center border transition-colors ${
                      isDone
                        ? 'bg-[#315C4C] border-[#315C4C] text-white'
                        : 'border-stone-300 hover:border-[#8BAF9C]'
                    }`}
                  >
                    {isDone && <Check className="w-3.5 h-3.5" />}
                  </button>
                  <div>
                    <h4
                      className={`text-sm font-semibold ${
                        isDone ? 'line-through text-stone-400' : 'text-stone-800'
                      }`}
                    >
                      {idx + 1}. {stretch.title}
                    </h4>
                    <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                      {stretch.instruction}
                    </p>
                  </div>
                </div>
                <span className="text-[11px] font-medium text-stone-400 shrink-0">
                  {stretch.duration}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-center text-xs text-stone-500">
        Completed {completedSteps.length} of {stretches.length} stretches
      </div>
    </div>
  );
};

/* 4. Three Gratitudes Quick Practice */
const GratitudeBuilder: React.FC<{
  onSave: (items: string[]) => void;
}> = ({ onSave }) => {
  const [items, setItems] = useState<string[]>(['', '', '']);

  const handleChange = (index: number, val: string) => {
    const updated = [...items];
    updated[index] = val;
    setItems(updated);
  };

  const handleDone = (e: React.FormEvent) => {
    e.preventDefault();
    const valid = items.filter((i) => i.trim().length > 0);
    if (valid.length === 0) return;
    sound.playChime(528, 2);
    onSave(valid);
  };

  return (
    <form onSubmit={handleDone} className="flex flex-col text-left">
      <div className="text-center mb-5">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#A05D41] bg-[#F7E2D7] px-3 py-1 rounded-full mb-2">
          <Heart className="w-3.5 h-3.5 fill-current" />
          <span>Gratitude Reflection</span>
        </div>
        <h3 className="font-display text-2xl font-semibold text-[#315C4C]">Three Simple Joys</h3>
        <p className="text-xs sm:text-sm text-stone-600 mt-1">
          Name three micro-moments of comfort, beauty, or kindness that touched your day.
        </p>
      </div>

      <div className="space-y-3 mb-6">
        {[0, 1, 2].map((idx) => (
          <div key={idx} className="flex items-center gap-3">
            <span className="w-6 text-center font-display text-base font-bold text-[#8BAF9C]">
              {idx + 1}.
            </span>
            <input
              type="text"
              value={items[idx]}
              onChange={(e) => handleChange(idx, e.target.value)}
              placeholder={
                idx === 0
                  ? 'e.g., The warm fragrance of morning cinnamon tea...'
                  : idx === 1
                  ? 'e.g., A kind message from a friend...'
                  : 'e.g., Seeing golden sunlight through green leaves...'
              }
              className="flex-1 px-3.5 py-2.5 rounded-xl border border-stone-200 bg-white text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:border-[#8BAF9C] focus:ring-2 focus:ring-[#8BAF9C]/20 transition-all"
            />
          </div>
        ))}
      </div>

      <button
        type="submit"
        disabled={items.every((i) => !i.trim())}
        className="w-full py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] font-medium text-sm hover:bg-[#25483B] disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm"
      >
        Save to My Journal
      </button>
    </form>
  );
};

/* 5. Sleep Sanctuary */
const SleepSanctuary: React.FC<{
  onComplete: (mins: number) => void;
  onClose: () => void;
}> = ({ onComplete }) => {
  const [isPlayingRain, setIsPlayingRain] = useState(sound.isAmbientActive());
  const [checklist, setChecklist] = useState<string[]>([
    'Dim overhead lights and switch to warm lamps',
    'Set phone to Do Not Disturb and put it across the room',
    'Sip a cup of warm water or herbal chamomile',
    'Release tomorrow’s tasks onto a notepad',
  ]);
  const [checked, setChecked] = useState<number[]>([]);

  const toggleCheck = (idx: number) => {
    if (checked.includes(idx)) {
      setChecked(checked.filter((i) => i !== idx));
    } else {
      setChecked([...checked, idx]);
    }
  };

  const handleToggleRain = () => {
    const newState = sound.toggleAmbientRain(!isPlayingRain);
    setIsPlayingRain(newState);
  };

  return (
    <div className="flex flex-col text-left">
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#2D4D6B] bg-[#D9E6F2] px-3 py-1 rounded-full mb-2">
          <Moon className="w-3.5 h-3.5" />
          <span>Restful Transition</span>
        </div>
        <h3 className="font-display text-2xl font-semibold text-[#315C4C]">Evening Sanctuary</h3>
        <p className="text-xs sm:text-sm text-stone-600 mt-1">
          Prepare your mind and body for deep, replenishing overnight rest.
        </p>
      </div>

      {/* Soundscape Card */}
      <div className="p-4 rounded-xl bg-[#F0F4F8] border border-[#C2D6E7] flex items-center justify-between mb-6">
        <div>
          <h4 className="text-sm font-semibold text-[#213C55]">Forest Rain Soundscape</h4>
          <p className="text-xs text-stone-600">Soft acoustic rain to calm brainwave activity</p>
        </div>
        <button
          onClick={handleToggleRain}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            isPlayingRain
              ? 'bg-[#2D4D6B] text-white shadow-xs'
              : 'bg-white border border-[#C2D6E7] text-[#2D4D6B] hover:bg-stone-50'
          }`}
        >
          {isPlayingRain ? 'Pause Sound' : 'Play Sound'}
        </button>
      </div>

      {/* Wind down checklist */}
      <h4 className="text-xs uppercase tracking-wider font-semibold text-stone-500 mb-2">
        Bedtime Unwind Checklist
      </h4>
      <div className="space-y-2 mb-6">
        {checklist.map((item, idx) => {
          const isDone = checked.includes(idx);
          return (
            <label
              key={idx}
              onClick={() => toggleCheck(idx)}
              className={`flex items-center gap-3 p-3 rounded-xl border text-xs cursor-pointer transition-colors ${
                isDone
                  ? 'bg-[#E1EFE8]/50 border-[#8BAF9C]/50 text-stone-500'
                  : 'bg-white border-stone-200 text-stone-800 hover:border-stone-300'
              }`}
            >
              <input
                type="checkbox"
                checked={isDone}
                readOnly
                className="w-4 h-4 text-[#315C4C] rounded accent-[#315C4C]"
              />
              <span className={isDone ? 'line-through' : ''}>{item}</span>
            </label>
          );
        })}
      </div>

      <button
        onClick={() => {
          onComplete(10);
          sound.playChime(396, 3);
        }}
        className="w-full py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] font-medium text-sm hover:bg-[#25483B] transition-all"
      >
        Complete Sleep Ritual (+10 min)
      </button>
    </div>
  );
};

/* 6. Mindful Nature Stroll Grounding */
const NatureWalkGuide: React.FC<{
  onComplete: (mins: number) => void;
  onClose: () => void;
}> = ({ onComplete }) => {
  const steps = [
    { count: '5', label: 'Things you can SEE', hint: 'Notice colors, bark texture, clouds drifting' },
    { count: '4', label: 'Things you can FEEL', hint: 'Breeze on your face, ground beneath shoes, fabric' },
    { count: '3', label: 'Things you HEAR', hint: 'Birds chirping, rustling leaves, distant water' },
    { count: '2', label: 'Things you SMELL', hint: 'Damp earth, pine needles, fresh rainfall' },
    { count: '1', label: 'Thing you APPRECIATE', hint: 'Gratitude for your body carrying you here' },
  ];

  return (
    <div className="flex flex-col text-left">
      <div className="text-center mb-6">
        <h3 className="font-display text-2xl font-semibold text-[#315C4C]">
          Mindful Nature Stroll
        </h3>
        <p className="text-xs sm:text-sm text-stone-600 mt-1">
          5-4-3-2-1 Sensory Grounding for your outdoor walk.
        </p>
      </div>

      <div className="space-y-3 mb-6">
        {steps.map((s, idx) => (
          <div key={idx} className="p-3.5 rounded-xl bg-white border border-stone-200/80 flex items-start gap-3">
            <span className="font-display text-2xl font-bold text-[#8BAF9C] w-7 text-center">
              {s.count}
            </span>
            <div>
              <h4 className="text-xs font-semibold tracking-wide uppercase text-stone-800">
                {s.label}
              </h4>
              <p className="text-xs text-stone-500 mt-0.5">{s.hint}</p>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={() => {
          onComplete(15);
          sound.playChime(528, 3);
        }}
        className="w-full py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] font-medium text-sm hover:bg-[#25483B] transition-all shadow-sm"
      >
        Complete Walk Reflection (+15 min)
      </button>
    </div>
  );
};
