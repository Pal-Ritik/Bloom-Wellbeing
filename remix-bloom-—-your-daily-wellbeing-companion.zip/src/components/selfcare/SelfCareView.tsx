import React, { useState } from 'react';
import { Wind, Sparkles, Activity, Heart, Moon, Compass, Clock, ArrowRight, Play, Check } from 'lucide-react';
import { SelfCareActivity } from '../../types/wellbeing';
import { SELF_CARE_ACTIVITIES } from '../../data/seedData';
import { LeafBranchIllustration } from '../common/BotanicalDecorations';

interface SelfCareViewProps {
  onOpenActivity: (activityId: string) => void;
  mindfulMinutes: number;
}

export const SelfCareView: React.FC<SelfCareViewProps> = ({
  onOpenActivity,
  mindfulMinutes,
}) => {
  const [filterCategory, setFilterCategory] = useState<'all' | 'calm' | 'body' | 'evening'>('all');

  const getIcon = (name: string) => {
    switch (name) {
      case 'Wind':
        return Wind;
      case 'Sparkles':
        return Sparkles;
      case 'Activity':
        return Activity;
      case 'Heart':
        return Heart;
      case 'Moon':
        return Moon;
      case 'Compass':
        return Compass;
      default:
        return Heart;
    }
  };

  const filteredActivities = SELF_CARE_ACTIVITIES.filter((act) => {
    if (filterCategory === 'all') return true;
    if (filterCategory === 'calm') return ['breathing', 'meditation', 'gratitude'].includes(act.id);
    if (filterCategory === 'body') return ['stretching', 'walk'].includes(act.id);
    if (filterCategory === 'evening') return ['sleep', 'meditation'].includes(act.id);
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#EBF2EE] via-white to-[#F5D8CC]/20 border border-[#8BAF9C]/25 p-6 sm:p-8 shadow-xs">
        <div className="relative z-10 max-w-xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#315C4C] uppercase tracking-wider mb-1">
            <Heart className="w-3.5 h-3.5" />
            <span>Restorative Sanctuary</span>
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#315C4C]">
            Gentle Self-Care Practices
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm mt-1 leading-relaxed">
            Short, pressure-free practices to nourish your nervous system. Pick whatever feels supportive right now.
          </p>
        </div>

        {/* Filter categories */}
        <div className="relative z-10 flex items-center gap-1.5 mt-5 p-1 bg-white border border-[#8BAF9C]/30 rounded-xl self-start overflow-x-auto text-xs font-medium shadow-2xs">
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              filterCategory === 'all'
                ? 'bg-[#315C4C] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            All Practices ({SELF_CARE_ACTIVITIES.length})
          </button>
          <button
            onClick={() => setFilterCategory('calm')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              filterCategory === 'calm'
                ? 'bg-[#315C4C] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Mind & Breath
          </button>
          <button
            onClick={() => setFilterCategory('body')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              filterCategory === 'body'
                ? 'bg-[#315C4C] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Movement & Nature
          </button>
          <button
            onClick={() => setFilterCategory('evening')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              filterCategory === 'evening'
                ? 'bg-[#315C4C] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Evening Rest
          </button>
        </div>

        <div className="absolute -bottom-6 -right-6 pointer-events-none opacity-20">
          <LeafBranchIllustration className="w-40 h-40 text-[#315C4C]" />
        </div>
      </div>

      {/* Grid of Recommendation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredActivities.map((activity) => {
          const Icon = getIcon(activity.iconName);
          return (
            <div
              key={activity.id}
              className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Header line with duration & icon */}
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center ${activity.colorTheme.bg} ${activity.colorTheme.text} transition-transform group-hover:scale-105`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex items-center gap-1 text-xs text-stone-500 font-medium">
                    <Clock className="w-3.5 h-3.5 text-stone-400" />
                    <span>{activity.duration}</span>
                  </div>
                </div>

                <h3 className="font-display text-lg font-bold text-[#315C4C] group-hover:text-[#25483B] transition-colors">
                  {activity.title}
                </h3>
                <p className="text-xs font-medium text-stone-500 mt-0.5">
                  {activity.tagline}
                </p>

                <p className="text-xs text-stone-600 mt-2.5 leading-relaxed">
                  {activity.description}
                </p>

                {/* Benefits text */}
                <div className="mt-4 pt-3 border-t border-stone-100 text-[11px] text-stone-500 flex items-start gap-1.5">
                  <Sparkles className="w-3 h-3 text-[#8BAF9C] shrink-0 mt-0.5" />
                  <span>{activity.benefits}</span>
                </div>
              </div>

              {/* Try This Button */}
              <div className="pt-4 mt-2">
                <button
                  onClick={() => onOpenActivity(activity.id)}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#FAF8F1] border border-[#8BAF9C]/30 text-[#315C4C] font-semibold text-xs sm:text-sm hover:bg-[#315C4C] hover:text-white transition-all shadow-2xs flex items-center justify-center gap-2 group/btn"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Try This</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Philosophy Callout Card */}
      <div className="rounded-2xl bg-gradient-to-br from-[#FAF8F1] via-[#EBF2EE] to-white border border-[#8BAF9C]/30 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-[#315C4C] text-[#FAF8F1] flex items-center justify-center shrink-0">
            <Heart className="w-5 h-5 fill-current" />
          </div>
          <div>
            <h4 className="font-display text-base font-semibold text-[#315C4C]">
              No Pressure, No Streaks Required
            </h4>
            <p className="text-xs text-stone-600 mt-0.5">
              Wellbeing is not a performance. If all you did today was rest, you did enough.
            </p>
          </div>
        </div>
        <div className="text-xs text-stone-500 shrink-0 tabular-nums">
          {mindfulMinutes} total minutes completed
        </div>
      </div>
    </div>
  );
};
