import React, { useState } from 'react';
import { Smile, Sparkles, Heart, Zap, ArrowRight, Flame, Clock, RefreshCw, CheckCircle2 } from 'lucide-react';
import { CheckIn, MoodLevel, SelfCareActivity, Affirmation } from '../../types/wellbeing';
import { MOOD_DEFINITIONS, DAILY_AFFIRMATIONS, SELF_CARE_ACTIVITIES } from '../../data/seedData';
import { LeafBranchIllustration, CalmMountainSun } from '../common/BotanicalDecorations';

interface DashboardProps {
  checkIns: CheckIn[];
  onOpenCheckIn: () => void;
  onOpenSelfCare: (activityId: string) => void;
  onNavigateTab: (tab: 'dashboard' | 'checkin' | 'journal' | 'insights' | 'selfcare') => void;
  mindfulMinutes: number;
}

export const Dashboard: React.FC<DashboardProps> = ({
  checkIns,
  onOpenCheckIn,
  onOpenSelfCare,
  onNavigateTab,
  mindfulMinutes,
}) => {
  const [affirmationIndex, setAffirmationIndex] = useState(0);

  // Latest check-in (most recent)
  const sortedCheckIns = [...checkIns].sort((a, b) => b.timestamp - a.timestamp);
  const latestCheckIn: CheckIn | undefined = sortedCheckIns[0];

  // Last 7 days check-in for trend
  const last7Days = sortedCheckIns.slice(0, 7).reverse();

  // Affirmation cycle
  const currentAffirmation: Affirmation = DAILY_AFFIRMATIONS[affirmationIndex % DAILY_AFFIRMATIONS.length];

  const handleNextAffirmation = () => {
    setAffirmationIndex((prev) => (prev + 1) % DAILY_AFFIRMATIONS.length);
  };

  // Dynamic self-care suggestion based on latest check-in mood/energy
  const getSuggestedActivity = (): SelfCareActivity => {
    if (!latestCheckIn) return SELF_CARE_ACTIVITIES[0];
    if (latestCheckIn.energy <= 2) {
      // low energy: suggest gentle stretching or restful sleep
      return SELF_CARE_ACTIVITIES[2]; // stretching
    }
    if (latestCheckIn.mood <= 2) {
      // low mood: suggest breathing or nature stroll
      return SELF_CARE_ACTIVITIES[0]; // breathing
    }
    if (latestCheckIn.emotions.includes('Anxious') || latestCheckIn.emotions.includes('Overwhelmed')) {
      return SELF_CARE_ACTIVITIES[0]; // breathing
    }
    return SELF_CARE_ACTIVITIES[1]; // grounding stillness
  };

  const suggested = getSuggestedActivity();

  // Streak calculation (consecutive days)
  const calculateStreak = (): number => {
    if (checkIns.length === 0) return 0;
    const uniqueDays = Array.from(new Set(checkIns.map((c) => c.date))).sort().reverse();
    return uniqueDays.length > 0 ? Math.min(uniqueDays.length, 7) : 0;
  };

  const streak = calculateStreak();

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16">
      {/* 1. Hero Greeting Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#EBF2EE] via-[#FAF8F1] to-[#F5D8CC]/20 border border-[#8BAF9C]/30 p-6 sm:p-8 shadow-xs">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#315C4C]">
              <span>Mindful Presence</span>
              <span aria-hidden="true">·</span>
              <span className="font-normal normal-case text-stone-600">Your calm space to blossom</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#315C4C] tracking-tight leading-tight">
              Hello, how are you feeling today?
            </h2>
            <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
              Take a quiet breath. No rush, no expectations. Tune into how your mind and body are resting right now.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            <button
              onClick={onOpenCheckIn}
              className="px-6 py-3.5 rounded-2xl bg-[#315C4C] text-[#FAF8F1] font-semibold text-sm sm:text-base hover:bg-[#25483B] active:scale-[0.98] transition-all shadow-md flex items-center justify-center gap-2.5 group"
            >
              <Smile className="w-5 h-5 text-[#8BAF9C] group-hover:scale-110 transition-transform" />
              <span>Start Check-in</span>
            </button>
            <button
              onClick={() => onOpenSelfCare(suggested.id)}
              className="px-5 py-3.5 rounded-2xl bg-white/80 border border-[#8BAF9C]/30 text-[#315C4C] font-medium text-sm hover:bg-white transition-all shadow-xs flex items-center justify-center gap-2"
            >
              <span>Try {suggested.title.split(' ')[0]}</span>
              <ArrowRight className="w-4 h-4 text-[#8BAF9C]" />
            </button>
          </div>
        </div>

        {/* Delicate background illustration */}
        <div className="absolute -bottom-6 -right-6 pointer-events-none opacity-20">
          <LeafBranchIllustration className="w-48 h-48 text-[#315C4C]" />
        </div>
      </div>

      {/* 2. Today's Summary & Progress Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Today's Mood Card */}
        <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-stone-500 mb-3">
              <span className="font-medium uppercase tracking-wider">Today's Mood</span>
              <span className="text-stone-400">
                {latestCheckIn ? latestCheckIn.timeOfDay : 'Awaiting check-in'}
              </span>
            </div>

            {latestCheckIn ? (
              <div className="flex items-center gap-4 my-2">
                <span className="text-4xl" role="img" aria-label={MOOD_DEFINITIONS[latestCheckIn.mood].label}>
                  {MOOD_DEFINITIONS[latestCheckIn.mood].emoji}
                </span>
                <div>
                  <h3 className="font-display text-xl font-bold text-[#315C4C]">
                    {MOOD_DEFINITIONS[latestCheckIn.mood].label}
                  </h3>
                  <p className="text-xs text-stone-600 mt-0.5">
                    {latestCheckIn.reflection || MOOD_DEFINITIONS[latestCheckIn.mood].description}
                  </p>
                </div>
              </div>
            ) : (
              <div className="py-3 text-center">
                <p className="text-sm text-stone-500">No check-in recorded yet today.</p>
                <button
                  onClick={onOpenCheckIn}
                  className="mt-2 text-xs font-semibold text-[#315C4C] hover:underline"
                >
                  Log morning mood →
                </button>
              </div>
            )}
          </div>

          {latestCheckIn && latestCheckIn.emotions.length > 0 && (
            <div className="pt-3 border-t border-stone-100 flex items-center gap-1.5 text-xs text-stone-600 flex-wrap">
              <span className="text-stone-400">Emotions:</span>
              {latestCheckIn.emotions.map((em, i) => (
                <span key={em} className="font-medium text-[#315C4C]">
                  {em}{i < latestCheckIn.emotions.length - 1 ? ' ·' : ''}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Energy Summary Card */}
        <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-stone-500 mb-3">
              <span className="font-medium uppercase tracking-wider">Energy Balance</span>
              <span className="flex items-center gap-1 text-[#315C4C] font-semibold">
                <Zap className="w-3.5 h-3.5 text-[#8BAF9C]" />
                Level {latestCheckIn ? latestCheckIn.energy : 3} of 5
              </span>
            </div>

            <div className="my-2">
              <div className="flex items-center justify-between text-xs font-medium text-stone-600 mb-1.5">
                <span>Drained</span>
                <span className="text-[#315C4C] font-semibold">
                  {latestCheckIn?.energy === 1 && 'Low reserves'}
                  {latestCheckIn?.energy === 2 && 'Gentle recovery'}
                  {latestCheckIn?.energy === 3 && 'Balanced equilibrium'}
                  {latestCheckIn?.energy === 4 && 'Vibrant & steady'}
                  {latestCheckIn?.energy === 5 && 'High vitality'}
                  {!latestCheckIn && 'Steady equilibrium'}
                </span>
                <span>Energized</span>
              </div>
              {/* Energy bar */}
              <div className="w-full bg-[#EBF2EE] h-2.5 rounded-full overflow-hidden flex gap-1 p-0.5">
                {[1, 2, 3, 4, 5].map((lvl) => (
                  <div
                    key={lvl}
                    className={`h-full flex-1 rounded-full transition-colors ${
                      lvl <= (latestCheckIn ? latestCheckIn.energy : 3)
                        ? 'bg-[#315C4C]'
                        : 'bg-transparent'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
            <span>Mindful rhythm</span>
            <span className="text-[#315C4C] font-medium">Optimal afternoon pace</span>
          </div>
        </div>

        {/* Progress & Streak Card */}
        <div className="rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-stone-500 mb-3">
              <span className="font-medium uppercase tracking-wider">Wellbeing Journey</span>
              <span className="flex items-center gap-1 text-[#9A5B32] font-semibold">
                <Flame className="w-3.5 h-3.5 fill-current" />
                {streak} Day Streak
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 my-1">
              <div className="p-2.5 rounded-xl bg-[#FAF8F1] border border-stone-200/50">
                <div className="flex items-center gap-1.5 text-stone-400 text-xs mb-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#315C4C]" />
                  <span>Logged</span>
                </div>
                <div className="font-display text-2xl font-bold text-[#315C4C] tabular-nums">
                  {checkIns.length}
                </div>
                <span className="text-[11px] text-stone-500">total check-ins</span>
              </div>

              <div className="p-2.5 rounded-xl bg-[#FAF8F1] border border-stone-200/50">
                <div className="flex items-center gap-1.5 text-stone-400 text-xs mb-1">
                  <Clock className="w-3.5 h-3.5 text-[#58447E]" />
                  <span>Mindful</span>
                </div>
                <div className="font-display text-2xl font-bold text-[#58447E] tabular-nums">
                  {mindfulMinutes}m
                </div>
                <span className="text-[11px] text-stone-500">practice minutes</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
            <span>Consistency</span>
            <span className="text-[#315C4C] font-medium">Gentle daily practice</span>
          </div>
        </div>
      </div>

      {/* 3. Middle Section: Weekly Trend Chart & Daily Affirmation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Weekly Mood Trend Chart (2 columns on lg) */}
        <div className="lg:col-span-2 rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-xs text-stone-400 font-medium uppercase tracking-wider">
                Emotional Trajectory
              </div>
              <h3 className="font-display text-lg sm:text-xl font-semibold text-[#315C4C]">
                Weekly Mood & Energy Trend
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('insights')}
              className="text-xs font-semibold text-[#315C4C] hover:text-[#25483B] flex items-center gap-1"
            >
              <span>View details</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* SVG Line Chart */}
          <div className="relative w-full h-48 sm:h-52 my-2">
            <svg viewBox="0 0 500 160" className="w-full h-full overflow-visible">
              <defs>
                <linearGradient id="moodGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#8BAF9C" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#8BAF9C" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Horizontal grid lines for moods 1 to 5 */}
              {[1, 2, 3, 4, 5].map((lvl) => {
                const y = 140 - (lvl - 1) * 30;
                return (
                  <g key={lvl}>
                    <line
                      x1="30"
                      y1={y}
                      x2="480"
                      y2={y}
                      stroke="#E5E7EB"
                      strokeDasharray="3 3"
                      strokeWidth="1"
                    />
                    <text
                      x="10"
                      y={y + 3}
                      className="text-[9px] fill-stone-400"
                      fontFamily="system-ui"
                    >
                      {lvl === 5 ? '😊' : lvl === 4 ? '🙂' : lvl === 3 ? '🌱' : lvl === 2 ? '☁️' : '🌧️'}
                    </text>
                  </g>
                );
              })}

              {/* Line path calculation */}
              {(() => {
                const points = last7Days.map((item, idx) => {
                  const x = 50 + idx * ((480 - 50) / Math.max(last7Days.length - 1, 1));
                  const y = 140 - (item.mood - 1) * 30;
                  return { x, y, item };
                });

                if (points.length < 2) return null;

                const pathD = points.reduce(
                  (acc, p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`),
                  ''
                );

                const areaD = `${pathD} L ${points[points.length - 1].x} 140 L ${points[0].x} 140 Z`;

                return (
                  <>
                    {/* Area fill */}
                    <path d={areaD} fill="url(#moodGradient)" />
                    {/* Trend Line */}
                    <path
                      d={pathD}
                      fill="none"
                      stroke="#315C4C"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    {/* Data Points */}
                    {points.map((p, i) => (
                      <g key={i} className="group cursor-pointer">
                        <circle
                          cx={p.x}
                          cy={p.y}
                          r="5"
                          fill="#FAF8F1"
                          stroke="#315C4C"
                          strokeWidth="2.5"
                          className="transition-transform group-hover:scale-125"
                        />
                        <text
                          x={p.x}
                          y="155"
                          textAnchor="middle"
                          className="text-[10px] fill-stone-500 font-medium"
                        >
                          {new Intl.DateTimeFormat('en-US', { weekday: 'narrow' }).format(
                            new Date(p.item.date + 'T12:00:00')
                          )}
                        </text>
                      </g>
                    ))}
                  </>
                );
              })()}
            </svg>
          </div>

          <div className="flex items-center justify-between text-xs text-stone-500 pt-3 border-t border-stone-100">
            <span className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#315C4C]" />
              <span>Mood Level (1-5)</span>
            </span>
            <span className="italic text-stone-600">
              Most stable during morning check-ins
            </span>
          </div>
        </div>

        {/* Daily Affirmation Card (1 column on lg) */}
        <div className="rounded-2xl bg-gradient-to-br from-[#E9E3F5]/40 via-white to-[#F5D8CC]/20 border border-[#E9E3F5] p-5 sm:p-6 shadow-xs flex flex-col justify-between relative overflow-hidden">
          <div>
            <div className="flex items-center justify-between text-xs mb-4">
              <span className="flex items-center gap-1.5 text-[#58447E] font-semibold uppercase tracking-wider text-[11px]">
                <Sparkles className="w-3.5 h-3.5 text-[#58447E]" />
                Daily Affirmation
              </span>
              <button
                onClick={handleNextAffirmation}
                className="p-1.5 rounded-lg text-stone-400 hover:text-[#58447E] hover:bg-white/80 transition-colors"
                title="Shuffle fresh affirmation"
                aria-label="Shuffle daily affirmation"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="my-3">
              <p className="font-display text-lg sm:text-xl font-medium text-[#2E4C3E] leading-relaxed italic">
                "{currentAffirmation.text}"
              </p>
              <div className="mt-3 flex items-center gap-2 text-xs text-stone-500">
                <span className="font-medium text-[#58447E]">{currentAffirmation.author}</span>
                <span aria-hidden="true">·</span>
                <span>{currentAffirmation.theme}</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-200/40 flex items-center justify-between text-xs">
            <span className="text-stone-500">A gentle thought for your day</span>
            <button
              onClick={handleNextAffirmation}
              className="text-[#58447E] font-medium hover:underline text-xs"
            >
              Next thought →
            </button>
          </div>
        </div>
      </div>

      {/* 4. Personalized Self-Care Recommendation Banner */}
      <div className="rounded-2xl bg-white border border-[#8BAF9C]/30 p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-5">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-[#EBF2EE] text-[#315C4C] flex items-center justify-center shrink-0">
            <Heart className="w-6 h-6 text-[#315C4C]" />
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
              <span className="font-semibold text-[#315C4C] uppercase tracking-wide">
                Personalized Suggestion
              </span>
              <span aria-hidden="true">·</span>
              <span>{suggested.duration}</span>
            </div>
            <h3 className="font-display text-lg font-bold text-stone-900">
              {suggested.title}
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 mt-0.5 max-w-xl">
              {suggested.description}
            </p>
          </div>
        </div>

        <button
          onClick={() => onOpenSelfCare(suggested.id)}
          className="px-5 py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] text-xs sm:text-sm font-semibold hover:bg-[#25483B] active:scale-[0.98] transition-all shadow-xs shrink-0 self-start sm:self-center"
        >
          Try This Exercise
        </button>
      </div>
    </div>
  );
};
