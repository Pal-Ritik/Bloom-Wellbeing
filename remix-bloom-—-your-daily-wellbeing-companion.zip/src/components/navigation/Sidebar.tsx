import React from 'react';
import { Home, Smile, BookOpen, BarChart3, Heart, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { ActiveTab } from '../../types/wellbeing';
import { BloomLogo, LeafBranchIllustration } from '../common/BotanicalDecorations';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isAmbientPlaying: boolean;
  onToggleAmbient: () => void;
  mindfulMinutes: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isAmbientPlaying,
  onToggleAmbient,
  mindfulMinutes,
}) => {
  const navItems: { id: ActiveTab; label: string; icon: React.ElementType; helper: string }[] = [
    { id: 'dashboard', label: 'Home', icon: Home, helper: 'Overview & today' },
    { id: 'checkin', label: 'Check-in', icon: Smile, helper: 'Log your feelings' },
    { id: 'journal', label: 'Journal', icon: BookOpen, helper: 'Private reflections' },
    { id: 'insights', label: 'Insights', icon: BarChart3, helper: 'Trends & balance' },
    { id: 'selfcare', label: 'Self-care', icon: Heart, helper: 'Restorative tools' },
  ];

  return (
    <aside
      className="hidden md:flex flex-col w-64 lg:w-72 bg-[#FAF8F1] border-r border-[#8BAF9C]/20 h-screen sticky top-0 p-5 justify-between shrink-0 select-none"
      aria-label="Main Navigation"
    >
      <div>
        {/* Brand Zone */}
        <div className="flex items-center gap-3 px-2 py-3 mb-6">
          <BloomLogo className="w-9 h-9 shrink-0 drop-shadow-xs" />
          <div className="flex flex-col">
            <span className="font-display text-xl font-semibold text-[#315C4C] tracking-tight leading-tight">
              Bloom
            </span>
            <span className="text-[11px] font-normal text-stone-500 tracking-wide">
              Daily Wellbeing Companion
            </span>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1.5" aria-label="Primary">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-xl text-left transition-all duration-200 group relative ${
                  isActive
                    ? 'bg-[#EBF2EE] text-[#315C4C] font-semibold shadow-xs'
                    : 'text-stone-600 hover:bg-[#F3EFE3] hover:text-[#315C4C]'
                }`}
                aria-current={isActive ? 'page' : undefined}
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                    isActive
                      ? 'bg-[#8BAF9C]/25 text-[#315C4C]'
                      : 'text-stone-400 group-hover:text-[#315C4C]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="text-sm truncate">{item.label}</span>
                  <span className="text-[11px] text-stone-400 font-normal truncate group-hover:text-stone-500">
                    {item.helper}
                  </span>
                </div>
                {isActive && (
                  <span
                    className="absolute right-3 w-1.5 h-1.5 rounded-full bg-[#315C4C]"
                    aria-hidden="true"
                  />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Area: Ambient & Mindful Minutes */}
      <div className="pt-4 border-t border-[#8BAF9C]/15 space-y-3">
        {/* Ambient rain toggle button */}
        <button
          onClick={onToggleAmbient}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl border text-xs transition-all ${
            isAmbientPlaying
              ? 'bg-[#E1EFE8] border-[#8BAF9C] text-[#224033] shadow-xs'
              : 'bg-white/80 border-[#8BAF9C]/20 text-stone-600 hover:bg-white'
          }`}
          title={isAmbientPlaying ? 'Pause calming ambient rain' : 'Play calming ambient rain sound'}
        >
          <div className="flex items-center gap-2">
            {isAmbientPlaying ? (
              <Volume2 className="w-4 h-4 text-[#315C4C] animate-pulse" />
            ) : (
              <VolumeX className="w-4 h-4 text-stone-400" />
            )}
            <span className="font-medium">
              {isAmbientPlaying ? 'Forest Rain Playing' : 'Calming Ambiance'}
            </span>
          </div>
          <span className="text-[10px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded bg-[#FAF8F1] text-stone-500 border border-stone-200">
            {isAmbientPlaying ? 'On' : 'Off'}
          </span>
        </button>

        {/* Mindful stats card with small botanical illustration */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-[#E9E3F5]/60 to-[#FAF8F1] border border-[#E9E3F5] p-3 text-left">
          <div className="flex items-center gap-2 mb-1 text-[#58447E]">
            <Sparkles className="w-3.5 h-3.5" />
            <span className="text-[11px] font-semibold tracking-wide uppercase">Mindful Time</span>
          </div>
          <div className="flex items-baseline gap-1 text-[#315C4C]">
            <span className="text-xl font-bold tabular-nums">{mindfulMinutes}</span>
            <span className="text-xs text-stone-500 font-normal">minutes logged</span>
          </div>
          <div className="absolute -bottom-4 -right-3 pointer-events-none opacity-30">
            <LeafBranchIllustration className="w-16 h-16 text-[#8BAF9C]" />
          </div>
        </div>
      </div>
    </aside>
  );
};
