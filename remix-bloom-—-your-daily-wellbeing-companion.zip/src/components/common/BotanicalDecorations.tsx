import React from 'react';

export const BloomLogo: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => (
  <svg
    viewBox="0 0 40 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Soft petal layers */}
    <circle cx="20" cy="20" r="18" fill="#8BAF9C" fillOpacity="0.16" />
    <path
      d="M20 7C16 13 14 17 20 23C26 17 24 13 20 7Z"
      fill="#315C4C"
    />
    <path
      d="M7 20C13 16 17 14 23 20C17 26 13 24 7 20Z"
      fill="#8BAF9C"
    />
    <path
      d="M20 33C24 27 26 23 20 17C14 23 16 27 20 33Z"
      fill="#315C4C"
      fillOpacity="0.75"
    />
    <path
      d="M33 20C27 24 23 26 17 20C23 14 27 16 33 20Z"
      fill="#8BAF9C"
      fillOpacity="0.75"
    />
    <circle cx="20" cy="20" r="3.5" fill="#FAF8F1" />
    <circle cx="20" cy="20" r="1.5" fill="#315C4C" />
  </svg>
);

export const LeafBranchIllustration: React.FC<{ className?: string }> = ({ className = 'w-24 h-24 text-[#8BAF9C]' }) => (
  <svg
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <path
      d="M20 100C40 85 60 55 95 25"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      opacity="0.4"
    />
    {/* Leaf 1 */}
    <path
      d="M40 85C35 70 45 60 55 68C58 78 48 88 40 85Z"
      fill="currentColor"
      fillOpacity="0.3"
      stroke="currentColor"
      strokeWidth="1.5"
    />
    {/* Leaf 2 */}
    <path
      d="M60 62C72 65 75 52 68 45C58 45 55 55 60 62Z"
      fill="currentColor"
      fillOpacity="0.35"
      stroke="currentColor"
      strokeWidth="1.5"
    />
    {/* Leaf 3 */}
    <path
      d="M75 42C72 30 84 22 90 30C92 38 82 45 75 42Z"
      fill="currentColor"
      fillOpacity="0.4"
      stroke="currentColor"
      strokeWidth="1.5"
    />
    {/* Tip leaf */}
    <path
      d="M95 25C98 15 106 18 102 26C98 32 94 28 95 25Z"
      fill="currentColor"
      fillOpacity="0.5"
      stroke="currentColor"
      strokeWidth="1.5"
    />
  </svg>
);

export const CalmMountainSun: React.FC<{ className?: string }> = ({ className = 'w-full h-32' }) => (
  <svg
    viewBox="0 0 400 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    preserveAspectRatio="none"
    aria-hidden="true"
  >
    <circle cx="200" cy="50" r="32" fill="#F5D8CC" fillOpacity="0.6" />
    <path
      d="M0 120L70 70C110 40 150 75 190 60C230 45 280 80 340 50L400 90V120H0Z"
      fill="#8BAF9C"
      fillOpacity="0.2"
    />
    <path
      d="M0 120L110 85C160 70 210 95 260 80C310 65 350 90 400 80V120H0Z"
      fill="#315C4C"
      fillOpacity="0.15"
    />
  </svg>
);
