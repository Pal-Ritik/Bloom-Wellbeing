import React from 'react';
import { Volume2, VolumeX, Plus, Sparkles } from 'lucide-react';
import { BloomLogo } from './BotanicalDecorations';
import { ActiveTab } from '../../types/wellbeing';

interface HeaderProps {
  activeTab: ActiveTab;
  onOpenCheckIn: () => void;
  isAmbientPlaying: boolean;
  onToggleAmbient: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenCheckIn,
  isAmbientPlaying,
  onToggleAmbient,
}) => {
  const getTabTitle = () => {
    switch (activeTab) {
      case 'dashboard':
        return 'Today at a Glance';
      case 'checkin':
        return 'Daily Mood Check-in';
      case 'journal':
        return 'Mindful Sanctuary Journal';
      case 'insights':
        return 'Wellbeing Trends & Insights';
      case 'selfcare':
        return 'Restorative Self-Care Practices';
      default:
        return 'Bloom Wellbeing';
    }
  };

  const todayFormatted = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  }).format(new Date());

  return (
    <header className="sticky top-0 z-20 bg-[#FAF8F1]/90 backdrop-blur-md border-b border-[#8BAF9C]/15 px-4 md:px-8 py-3.5 transition-all">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
        {/* Left: Section name & Date */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="md:hidden">
            <BloomLogo className="w-7 h-7" />
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2 text-xs text-stone-500 font-medium">
              <span className="truncate">{todayFormatted}</span>
              <span aria-hidden="true" className="text-stone-300">·</span>
              <span className="text-[#315C4C] font-semibold flex items-center gap-1">
                <Sparkles className="w-3 h-3 inline text-[#8BAF9C]" />
                Gentle Day
              </span>
            </div>
            <h1 className="text-base sm:text-lg font-display font-semibold text-[#315C4C] truncate">
              {getTabTitle()}
            </h1>
          </div>
        </div>

        {/* Right Action buttons */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Mobile Ambiance Button */}
          <button
            onClick={onToggleAmbient}
            className={`md:hidden p-2 rounded-xl border transition-colors ${
              isAmbientPlaying
                ? 'bg-[#E1EFE8] border-[#8BAF9C] text-[#224033]'
                : 'bg-white border-[#8BAF9C]/20 text-stone-600'
            }`}
            title="Toggle calming rain sound"
            aria-label="Toggle ambient sound"
          >
            {isAmbientPlaying ? (
              <Volume2 className="w-4 h-4 text-[#315C4C]" />
            ) : (
              <VolumeX className="w-4 h-4 text-stone-400" />
            )}
          </button>

          {/* Quick Check-in CTA button */}
          {activeTab !== 'checkin' && (
            <button
              onClick={onOpenCheckIn}
              className="flex items-center gap-1.5 px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-medium bg-[#315C4C] text-[#FAF8F1] hover:bg-[#25483B] active:scale-[0.98] transition-all shadow-xs shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Mood</span>
            </button>
          )}

          {/* Calm profile avatar icon */}
          <div
            className="w-8 h-8 rounded-full bg-[#EBF2EE] border border-[#8BAF9C]/40 flex items-center justify-center text-xs font-semibold text-[#315C4C] select-none"
            title="Shivendra's Garden"
          >
            S
          </div>
        </div>
      </div>
    </header>
  );
};
