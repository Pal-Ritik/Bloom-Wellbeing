import React, { useState } from 'react';
import { Check, Sparkles, Heart, Zap, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { MoodLevel, CheckIn } from '../../types/wellbeing';
import { MOOD_DEFINITIONS, AVAILABLE_EMOTIONS } from '../../data/seedData';
import { sound } from '../../utils/audio';

interface MoodCheckinProps {
  onSaveCheckIn: (checkIn: Omit<CheckIn, 'id' | 'timestamp'>) => void;
  onNavigateHome: () => void;
}

export const MoodCheckin: React.FC<MoodCheckinProps> = ({
  onSaveCheckIn,
  onNavigateHome,
}) => {
  const [selectedMood, setSelectedMood] = useState<MoodLevel>(4);
  const [energyLevel, setEnergyLevel] = useState<number>(3);
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>(['Calm']);
  const [reflection, setReflection] = useState<string>('');
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const toggleEmotion = (emotion: string) => {
    if (selectedEmotions.includes(emotion)) {
      setSelectedEmotions(selectedEmotions.filter((e) => e !== emotion));
    } else {
      setSelectedEmotions([...selectedEmotions, emotion]);
    }
  };

  const getEnergyLabel = (val: number) => {
    switch (val) {
      case 1:
        return '1 — Drained & Depleted';
      case 2:
        return '2 — Low & Needing Rest';
      case 3:
        return '3 — Balanced & Steady';
      case 4:
        return '4 — Vibrant & Engaged';
      case 5:
        return '5 — Highly Energized';
      default:
        return `${val} of 5`;
    }
  };

  const getTimeOfDay = (): 'Morning' | 'Afternoon' | 'Evening' | 'Night' => {
    const hours = new Date().getHours();
    if (hours >= 5 && hours < 12) return 'Morning';
    if (hours >= 12 && hours < 17) return 'Afternoon';
    if (hours >= 17 && hours < 21) return 'Evening';
    return 'Night';
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    sound.playChime(528, 3.2);

    onSaveCheckIn({
      date: dateStr,
      time: timeStr,
      mood: selectedMood,
      energy: energyLevel,
      emotions: selectedEmotions,
      reflection: reflection.trim() || undefined,
      timeOfDay: getTimeOfDay(),
    });

    setIsSaved(true);
  };

  if (isSaved) {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4 text-center animate-fadeIn">
        <div className="w-16 h-16 rounded-full bg-[#E1EFE8] text-[#315C4C] mx-auto flex items-center justify-center mb-4 shadow-xs">
          <CheckCircle2 className="w-8 h-8 text-[#315C4C]" />
        </div>
        <h2 className="font-display text-3xl font-semibold text-[#315C4C]">
          Thank you for checking in
        </h2>
        <p className="text-stone-600 mt-2 max-w-md mx-auto text-sm leading-relaxed">
          Your feelings have been gently honored and recorded in your sanctuary. Remember, honoring where you are right now is the first step of healing.
        </p>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={onNavigateHome}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] text-sm font-semibold hover:bg-[#25483B] transition-all shadow-sm"
          >
            Return to Dashboard
          </button>
          <button
            onClick={() => {
              setIsSaved(false);
              setReflection('');
            }}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-stone-200 bg-white text-stone-700 text-sm font-medium hover:bg-stone-50 transition-colors"
          >
            Log Another Note
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto pb-16">
      <form onSubmit={handleSave} className="space-y-8">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#315C4C] bg-[#8BAF9C]/20 px-3 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Honoring This Moment</span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#315C4C]">
            How are you feeling right now?
          </h2>
          <p className="text-stone-600 text-sm max-w-md mx-auto">
            Choose what resonates most true right now. There are no wrong answers.
          </p>
        </div>

        {/* 1. Five Mood Options */}
        <div className="bg-white rounded-3xl border border-[#8BAF9C]/25 p-6 shadow-xs space-y-4">
          <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider">
            1. Select Your Mood
          </label>

          <div className="grid grid-cols-5 gap-2 sm:gap-3">
            {([1, 2, 3, 4, 5] as MoodLevel[]).map((level) => {
              const meta = MOOD_DEFINITIONS[level];
              const isSelected = selectedMood === level;
              return (
                <button
                  type="button"
                  key={level}
                  onClick={() => {
                    setSelectedMood(level);
                    sound.playChime(300 + level * 60, 1);
                  }}
                  className={`flex flex-col items-center justify-center p-3 sm:p-4 rounded-2xl border-2 transition-all ${
                    isSelected
                      ? 'border-[#315C4C] bg-[#EBF2EE] scale-102 shadow-xs'
                      : 'border-transparent bg-[#FAF8F1] hover:bg-[#F3EFE3] text-stone-600'
                  }`}
                  aria-pressed={isSelected}
                >
                  <span className="text-3xl sm:text-4xl mb-1.5 transition-transform" role="img" aria-label={meta.label}>
                    {meta.emoji}
                  </span>
                  <span className={`text-xs font-semibold ${isSelected ? 'text-[#315C4C]' : 'text-stone-700'}`}>
                    {meta.label}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="p-3 rounded-xl bg-[#FAF8F1] border border-[#8BAF9C]/20 text-center text-xs text-stone-600">
            <span className="font-semibold text-[#315C4C]">{MOOD_DEFINITIONS[selectedMood].label}:</span>{' '}
            {MOOD_DEFINITIONS[selectedMood].description}
          </div>
        </div>

        {/* 2. Interactive Energy Slider */}
        <div className="bg-white rounded-3xl border border-[#8BAF9C]/25 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-[#8BAF9C]" />
              <span>2. Energy Level</span>
            </label>
            <span className="text-xs font-semibold text-[#315C4C]">
              {getEnergyLabel(energyLevel)}
            </span>
          </div>

          <div className="space-y-2 py-2">
            <input
              type="range"
              min="1"
              max="5"
              step="1"
              value={energyLevel}
              onChange={(e) => setEnergyLevel(parseInt(e.target.value, 10))}
              className="w-full h-2.5 bg-[#EBF2EE] rounded-lg appearance-none cursor-pointer accent-[#315C4C]"
            />
            <div className="flex justify-between text-[11px] text-stone-400 font-medium px-1">
              <span>1 · Drained</span>
              <span>2 · Low</span>
              <span>3 · Balanced</span>
              <span>4 · Vibrant</span>
              <span>5 · High Energy</span>
            </div>
          </div>
        </div>

        {/* 3. Optional Emotion Tags */}
        <div className="bg-white rounded-3xl border border-[#8BAF9C]/25 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              3. Emotions You Feel (Optional)
            </label>
            <span className="text-[11px] text-stone-400">
              {selectedEmotions.length} selected
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {AVAILABLE_EMOTIONS.map((emotion) => {
              const isSelected = selectedEmotions.includes(emotion);
              return (
                <button
                  type="button"
                  key={emotion}
                  onClick={() => toggleEmotion(emotion)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                    isSelected
                      ? 'bg-[#315C4C] text-[#FAF8F1] border-[#315C4C] shadow-xs'
                      : 'bg-[#FAF8F1] text-stone-700 border-stone-200/70 hover:border-[#8BAF9C]'
                  }`}
                  aria-pressed={isSelected}
                >
                  {isSelected && <Check className="w-3 h-3 inline mr-1 stroke-2" />}
                  {emotion}
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Optional Reflection Text */}
        <div className="bg-white rounded-3xl border border-[#8BAF9C]/25 p-6 shadow-xs space-y-3">
          <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider">
            4. Personal Reflection (Optional)
          </label>
          <textarea
            rows={3}
            value={reflection}
            onChange={(e) => setReflection(e.target.value)}
            placeholder="What is giving you comfort or weighing on your thoughts right now? Write as much or as little as you like..."
            className="w-full px-4 py-3 rounded-2xl border border-stone-200 bg-[#FAF8F1] text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:border-[#8BAF9C] focus:ring-2 focus:ring-[#8BAF9C]/20 transition-all resize-none"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-4 pt-2">
          <button
            type="button"
            onClick={onNavigateHome}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-medium text-stone-600 hover:text-stone-900 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Cancel</span>
          </button>

          <button
            type="submit"
            className="px-8 py-3 rounded-2xl bg-[#315C4C] text-[#FAF8F1] text-sm sm:text-base font-semibold hover:bg-[#25483B] active:scale-[0.98] transition-all shadow-md flex items-center gap-2"
          >
            <Heart className="w-4 h-4 text-[#8BAF9C] fill-current" />
            <span>Save Check-in</span>
          </button>
        </div>
      </form>
    </div>
  );
};
