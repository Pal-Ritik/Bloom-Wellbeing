import React, { useState } from 'react';
import { Search, Plus, Edit2, Trash2, Heart, Sparkles, BookOpen, X, Check, Filter } from 'lucide-react';
import { JournalEntry, MoodLevel } from '../../types/wellbeing';
import { MOOD_DEFINITIONS, JOURNAL_PROMPTS } from '../../data/seedData';
import { sound } from '../../utils/audio';

interface JournalViewProps {
  entries: JournalEntry[];
  onAddEntry: (entry: Omit<JournalEntry, 'id' | 'timestamp'>) => void;
  onUpdateEntry: (id: string, updated: Partial<JournalEntry>) => void;
  onDeleteEntry: (id: string) => void;
}

export const JournalView: React.FC<JournalViewProps> = ({
  entries,
  onAddEntry,
  onUpdateEntry,
  onDeleteEntry,
}) => {
  const [isWriting, setIsWriting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMoodFilter, setSelectedMoodFilter] = useState<MoodLevel | 'all'>('all');
  const [activeViewingEntry, setActiveViewingEntry] = useState<JournalEntry | null>(null);
  const [editingEntryId, setEditingEntryId] = useState<string | null>(null);

  // Form State
  const [entryTitle, setEntryTitle] = useState('');
  const [entryContent, setEntryContent] = useState('');
  const [entryMood, setEntryMood] = useState<MoodLevel>(4);
  const [entryPrompt, setEntryPrompt] = useState<string | undefined>(undefined);
  const [entryTagInput, setEntryTagInput] = useState('');
  const [entryTags, setEntryTags] = useState<string[]>(['Reflection']);

  const handleOpenNew = (promptText?: string) => {
    setEditingEntryId(null);
    setEntryTitle(promptText ? promptText.slice(0, 40) + '...' : '');
    setEntryContent('');
    setEntryMood(4);
    setEntryPrompt(promptText);
    setEntryTags(['Mindfulness']);
    setIsWriting(true);
  };

  const handleOpenEdit = (entry: JournalEntry) => {
    setEditingEntryId(entry.id);
    setEntryTitle(entry.title);
    setEntryContent(entry.content);
    setEntryMood(entry.mood);
    setEntryPrompt(entry.promptUsed);
    setEntryTags(entry.tags);
    setIsWriting(true);
    setActiveViewingEntry(null);
  };

  const handleAddTag = () => {
    if (entryTagInput.trim() && !entryTags.includes(entryTagInput.trim())) {
      setEntryTags([...entryTags, entryTagInput.trim()]);
      setEntryTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setEntryTags(entryTags.filter((t) => t !== tag));
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!entryContent.trim()) return;

    sound.playChime(528, 2.5);

    if (editingEntryId) {
      onUpdateEntry(editingEntryId, {
        title: entryTitle.trim() || 'Untitled Reflection',
        content: entryContent.trim(),
        mood: entryMood,
        promptUsed: entryPrompt,
        tags: entryTags,
      });
    } else {
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

      onAddEntry({
        title: entryTitle.trim() || 'Untitled Reflection',
        content: entryContent.trim(),
        date: dateStr,
        time: timeStr,
        mood: entryMood,
        promptUsed: entryPrompt,
        tags: entryTags,
        isFavorite: false,
      });
    }

    setIsWriting(false);
    setEditingEntryId(null);
  };

  // Filtered entries
  const filteredEntries = entries.filter((entry) => {
    const matchesSearch =
      entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesMood = selectedMoodFilter === 'all' || entry.mood === selectedMoodFilter;

    return matchesSearch && matchesMood;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      {/* Top Banner & Guided Prompt Carousel */}
      <div className="rounded-3xl bg-gradient-to-br from-[#EBF2EE] via-white to-[#F5D8CC]/20 border border-[#8BAF9C]/25 p-6 sm:p-7 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#315C4C] uppercase tracking-wider">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Sanctuary Journal</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#315C4C] mt-1">
              Quiet Thoughts & Musings
            </h2>
          </div>

          <button
            onClick={() => handleOpenNew()}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] text-xs sm:text-sm font-semibold hover:bg-[#25483B] active:scale-[0.98] transition-all shadow-sm self-start sm:self-auto shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Write New Entry</span>
          </button>
        </div>

        {/* Guided prompt sparks */}
        <div className="pt-3 border-t border-[#8BAF9C]/15">
          <span className="text-xs font-medium text-stone-500 mb-2 block">
            Gentle writing prompts to spark reflection:
          </span>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {JOURNAL_PROMPTS.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleOpenNew(prompt)}
                className="px-3.5 py-1.5 rounded-xl bg-white border border-[#8BAF9C]/30 text-stone-700 text-xs font-medium hover:border-[#315C4C] hover:text-[#315C4C] whitespace-nowrap transition-colors shadow-2xs shrink-0"
              >
                "{prompt}"
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Search & Mood Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search reflections by word, prompt, or tag..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-stone-200 bg-white text-xs sm:text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:border-[#8BAF9C] focus:ring-2 focus:ring-[#8BAF9C]/20 transition-all"
          />
        </div>

        {/* Mood filter segmented buttons */}
        <div className="flex items-center gap-1 p-1 bg-[#EBF2EE] rounded-xl self-start sm:self-auto overflow-x-auto text-xs font-medium shrink-0">
          <button
            onClick={() => setSelectedMoodFilter('all')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              selectedMoodFilter === 'all'
                ? 'bg-[#315C4C] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            All ({entries.length})
          </button>
          {([5, 4, 3, 2, 1] as MoodLevel[]).map((lvl) => {
            const count = entries.filter((e) => e.mood === lvl).length;
            if (count === 0 && selectedMoodFilter !== lvl) return null;
            return (
              <button
                key={lvl}
                onClick={() => setSelectedMoodFilter(lvl)}
                className={`px-2.5 py-1.5 rounded-lg transition-all flex items-center gap-1 ${
                  selectedMoodFilter === lvl
                    ? 'bg-[#315C4C] text-white shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <span>{MOOD_DEFINITIONS[lvl].emoji}</span>
                <span className="tabular-nums">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Journal Entries Grid */}
      {filteredEntries.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-stone-300 bg-white p-12 text-center space-y-3">
          <BookOpen className="w-10 h-10 text-stone-300 mx-auto" />
          <h3 className="font-display text-lg font-semibold text-stone-700">
            No reflections found
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            {searchQuery
              ? 'Try adjusting your search query or removing mood filters.'
              : 'Your journal is ready for your first words. A thought, a gratitude, or a quiet pause.'}
          </p>
          <button
            onClick={() => handleOpenNew()}
            className="px-4 py-2 rounded-xl bg-[#315C4C] text-white text-xs font-medium hover:bg-[#25483B] transition-colors"
          >
            Write First Entry
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredEntries.map((entry) => {
            const moodMeta = MOOD_DEFINITIONS[entry.mood];
            return (
              <div
                key={entry.id}
                onClick={() => setActiveViewingEntry(entry)}
                className="group rounded-2xl bg-white border border-[#8BAF9C]/25 p-5 shadow-xs hover:shadow-md hover:border-[#8BAF9C] transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  {/* Clean unboxed metadata with separators */}
                  <div className="flex items-center justify-between text-xs text-stone-500 mb-2.5">
                    <div className="flex items-center gap-1.5 font-medium">
                      <span className="text-base" role="img" aria-label={moodMeta.label}>
                        {moodMeta.emoji}
                      </span>
                      <span className="text-stone-700">{moodMeta.label}</span>
                      <span aria-hidden="true" className="text-stone-300">·</span>
                      <span className="text-stone-400">
                        {new Intl.DateTimeFormat('en-US', {
                          month: 'short',
                          day: 'numeric',
                        }).format(new Date(entry.date + 'T12:00:00'))}
                      </span>
                    </div>

                    <div
                      className="flex items-center gap-1 opacity-80 group-hover:opacity-100"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        onClick={() =>
                          onUpdateEntry(entry.id, { isFavorite: !entry.isFavorite })
                        }
                        className={`p-1.5 rounded-lg hover:bg-stone-100 transition-colors ${
                          entry.isFavorite ? 'text-amber-500' : 'text-stone-300'
                        }`}
                        title={entry.isFavorite ? 'Favorited' : 'Add to favorites'}
                      >
                        <Heart
                          className={`w-4 h-4 ${entry.isFavorite ? 'fill-current' : ''}`}
                        />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(entry)}
                        className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
                        title="Edit reflection"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('Delete this journal reflection?')) {
                            onDeleteEntry(entry.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-stone-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                        title="Delete reflection"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h3 className="font-display text-lg font-bold text-[#315C4C] group-hover:text-[#25483B] transition-colors line-clamp-1">
                    {entry.title}
                  </h3>

                  {entry.promptUsed && (
                    <p className="text-[11px] text-stone-400 italic line-clamp-1 mt-0.5">
                      Prompt: "{entry.promptUsed}"
                    </p>
                  )}

                  <p className="text-xs sm:text-sm text-stone-600 line-clamp-3 mt-2 leading-relaxed">
                    {entry.content}
                  </p>
                </div>

                {/* Tags line */}
                {entry.tags.length > 0 && (
                  <div className="pt-3 mt-3 border-t border-stone-100 flex items-center gap-2 text-[11px] text-stone-400 flex-wrap">
                    {entry.tags.map((t, idx) => (
                      <span key={t}>
                        #{t}
                        {idx < entry.tags.length - 1 ? ' ' : ''}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Reading Modal */}
      {activeViewingEntry && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-xs animate-fadeIn"
        >
          <div className="bg-[#FAF8F1] border border-[#8BAF9C]/30 rounded-3xl w-full max-w-2xl max-h-[85vh] overflow-y-auto shadow-2xl p-6 sm:p-8 relative">
            <button
              onClick={() => setActiveViewingEntry(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs text-stone-500 mb-3">
              <span className="text-xl">
                {MOOD_DEFINITIONS[activeViewingEntry.mood].emoji}
              </span>
              <span className="font-semibold text-[#315C4C]">
                {MOOD_DEFINITIONS[activeViewingEntry.mood].label}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {new Intl.DateTimeFormat('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                }).format(new Date(activeViewingEntry.date + 'T12:00:00'))}
              </span>
              <span aria-hidden="true">·</span>
              <span>{activeViewingEntry.time}</span>
            </div>

            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#315C4C]">
              {activeViewingEntry.title}
            </h2>

            {activeViewingEntry.promptUsed && (
              <div className="my-3 px-3 py-2 rounded-xl bg-[#EBF2EE] text-xs text-[#224033] italic">
                Prompt: "{activeViewingEntry.promptUsed}"
              </div>
            )}

            <div className="my-6 text-sm sm:text-base text-stone-700 leading-relaxed whitespace-pre-wrap">
              {activeViewingEntry.content}
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-stone-200 text-xs">
              <div className="flex items-center gap-2 text-stone-500">
                {activeViewingEntry.tags.map((t) => (
                  <span key={t}>#{t}</span>
                ))}
              </div>
              <button
                onClick={() => handleOpenEdit(activeViewingEntry)}
                className="px-4 py-2 rounded-xl bg-stone-200 text-stone-700 hover:bg-stone-300 font-medium"
              >
                Edit Entry
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Writing / Editing Modal */}
      {isWriting && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-xs animate-fadeIn"
        >
          <div className="bg-[#FAF8F1] border border-[#8BAF9C]/30 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-8 relative">
            <button
              onClick={() => setIsWriting(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <form onSubmit={handleSaveForm} className="space-y-4">
              <div>
                <span className="text-xs font-semibold text-[#315C4C] uppercase tracking-wide">
                  {editingEntryId ? 'Edit Reflection' : 'New Journal Reflection'}
                </span>
                <input
                  type="text"
                  value={entryTitle}
                  onChange={(e) => setEntryTitle(e.target.value)}
                  placeholder="Title of this reflection..."
                  className="w-full mt-2 text-xl sm:text-2xl font-display font-semibold text-[#315C4C] placeholder-stone-400 bg-transparent border-b border-stone-300 focus:border-[#315C4C] focus:outline-none pb-2 transition-colors"
                />
              </div>

              {entryPrompt && (
                <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-[#EBF2EE] text-xs text-[#224033]">
                  <span className="italic">"{entryPrompt}"</span>
                  <button
                    type="button"
                    onClick={() => setEntryPrompt(undefined)}
                    className="text-stone-400 hover:text-stone-600 ml-2"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Mood selector in entry */}
              <div className="flex items-center gap-3 py-1">
                <span className="text-xs font-medium text-stone-500">Mood:</span>
                <div className="flex items-center gap-1.5">
                  {([1, 2, 3, 4, 5] as MoodLevel[]).map((lvl) => (
                    <button
                      type="button"
                      key={lvl}
                      onClick={() => setEntryMood(lvl)}
                      className={`p-1.5 rounded-lg border text-base transition-transform ${
                        entryMood === lvl
                          ? 'bg-[#EBF2EE] border-[#315C4C] scale-110 shadow-xs'
                          : 'border-transparent hover:bg-stone-200/50'
                      }`}
                      title={MOOD_DEFINITIONS[lvl].label}
                    >
                      {MOOD_DEFINITIONS[lvl].emoji}
                    </button>
                  ))}
                </div>
              </div>

              {/* Distraction free editor */}
              <div>
                <textarea
                  rows={8}
                  required
                  value={entryContent}
                  onChange={(e) => setEntryContent(e.target.value)}
                  placeholder="Let your thoughts flow freely. This space is entirely yours..."
                  className="w-full p-4 rounded-2xl border border-stone-200 bg-white text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:border-[#8BAF9C] focus:ring-2 focus:ring-[#8BAF9C]/20 transition-all leading-relaxed"
                />
              </div>

              {/* Tag Editor */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={entryTagInput}
                    onChange={(e) => setEntryTagInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddTag();
                      }
                    }}
                    placeholder="Add a tag (e.g., Nature, Gratitude)..."
                    className="flex-1 px-3 py-1.5 rounded-xl border border-stone-200 bg-white text-xs text-stone-800 focus:outline-none focus:border-[#8BAF9C]"
                  />
                  <button
                    type="button"
                    onClick={handleAddTag}
                    className="px-3 py-1.5 rounded-xl bg-stone-200 text-stone-700 text-xs font-medium hover:bg-stone-300"
                  >
                    Add
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {entryTags.map((t) => (
                    <span
                      key={t}
                      className="inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-lg bg-stone-200 text-stone-700"
                    >
                      #{t}
                      <button
                        type="button"
                        onClick={() => handleRemoveTag(t)}
                        className="hover:text-stone-900"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Save & Cancel */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsWriting(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-stone-600 hover:text-stone-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#315C4C] text-[#FAF8F1] text-xs sm:text-sm font-semibold hover:bg-[#25483B] transition-all shadow-sm"
                >
                  {editingEntryId ? 'Update Reflection' : 'Save Reflection'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
